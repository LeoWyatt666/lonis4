<?

// Db config
$dbconf = array (
	'mysql_host' => 'localhost',
	'mysql_user' => 'lonis',
	'mysql_password' => 'lonis',
	'mysql_db' => 'lonis',
	'mysql_prefix' => '',
);

$comms = [
	'cc' => 'https://cosy-climbing.net/demoz.txt',
	'xj' => 'https://xtreme-jumps.eu/demos.txt',
	'ru' => 'http://kzru.one/demos.txt',
	'rush' => 'http://kz-rush.ru/demos.txt',
	'notoff' => 'https://cosy-climbing.net/demos_notoff.txt',
];